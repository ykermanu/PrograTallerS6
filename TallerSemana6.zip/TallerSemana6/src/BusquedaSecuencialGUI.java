import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BusquedaSecuencialGUI {
    private JPanel pGeneral;
    private JTextField txtbuscarNumero;
    private JButton buscarButton;
    private JLabel Estado;
    private int [] array={2,4,6,8,10,12,14};


    public BusquedaSecuencialGUI() {
        buscarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                encontrarNumero();
            }
        });
    }

    private void encontrarNumero(){
        String numero= txtbuscarNumero.getText();
        try{
            int numeroBuscado= Integer.parseInt(numero);
            int indice= BusquedaSecuencial.buscar(array,numeroBuscado);
            if(indice!=-1){
                Estado.setText("El " + numero + " esta en la posicion : " + indice);
            }else{
                Estado.setText("El " + numero + " no existe en el arreglo");

            }

        }catch(NumberFormatException excep){
            JOptionPane.showMessageDialog(null,"Ingrese un numero valido");
        }

    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("BusquedaSecuencialGUI");
        frame.setContentPane(new BusquedaSecuencialGUI().pGeneral);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
